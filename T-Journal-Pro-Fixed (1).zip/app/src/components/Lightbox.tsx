import { useEffect, useCallback, memo } from 'react';
import { useStore } from '@/store/useStore';
import { X } from 'lucide-react';

function Lightbox() {
  const { lightboxOpen, lightboxSrc, lightboxLabel, setLightboxOpen } = useStore();

  const close = useCallback(() => {
    setLightboxOpen(false);
  }, [setLightboxOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && lightboxOpen) close();
    };
    window.addEventListener('keydown', onKey);

    if (lightboxOpen) {
      document.body.style.overflow = 'hidden';
    }

    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [lightboxOpen, close]);

  if (!lightboxOpen) return null;

  return (
    <div
      className="lightbox open"
      onClick={close}
      role="dialog"
      aria-modal="true"
      aria-label={lightboxLabel || 'Image viewer'}
    >
      <button
        className="lightbox-close"
        onClick={close}
        aria-label="Close image viewer"
      >
        <X size={20} />
      </button>
      <div onClick={(e) => e.stopPropagation()}>
        <img
          className="lightbox-img"
          src={lightboxSrc}
          alt={lightboxLabel || 'Trade screenshot'}
          loading="eager"
        />
        {lightboxLabel && (
          <div
            style={{
              position: 'absolute',
              bottom: '-30px',
              left: '50%',
              transform: 'translateX(-50%)',
              fontSize: '11px',
              color: 'var(--t3)',
              fontWeight: 700,
              letterSpacing: '1px',
              textTransform: 'uppercase',
            }}
          >
            {lightboxLabel}
          </div>
        )}
      </div>
    </div>
  );
}

export default memo(Lightbox);
