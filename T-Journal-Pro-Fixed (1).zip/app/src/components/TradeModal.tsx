import { useCallback, useEffect, useState, memo } from 'react';
import { useStore } from '@/store/useStore';
import { saveMonthTrades, loadAllTrades } from '@/lib/db';
import { calcStats, fileToBase64, hapticMedium, generateTradeId } from '@/lib/utils';
import { MISTAKES_LIST, IMAGE_TYPE_CONFIG } from '@/types';
import type { Trade, TradeImageType } from '@/types';
import { X, Plus, Minus, Check } from 'lucide-react';

function TradeModal() {
  const {
    tradeModalOpen, setTradeModalOpen,
    editingTradeId, setEditingTradeId,
    year, month, selDay,
    monthTrades, setMonthTrades,
    setAllTrades,
    formImages, setFormImages,
    formResult, setFormResult,
    formDirection, setFormDirection,
    formTags, setFormTags,
    formMistakes, setFormMistakes,
    addToast,
    triggerRefresh,
    setLightboxOpen,
    setLightboxSrc,
    setLightboxLabel,
  } = useStore();

  const [pair, setPair] = useState('XAUUSD');
  const [lot, setLot] = useState('');
  const [entry, setEntry] = useState('');
  const [tp, setTp] = useState('');
  const [sl, setSl] = useState('');
  const [rrr, setRrr] = useState('');
  const [pnl, setPnl] = useState('');
  const [notes, setNotes] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [customMistake, setCustomMistake] = useState('');
  const [saving, setSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Reset form
  const resetForm = useCallback(() => {
    setPair('XAUUSD');
    setLot('');
    setEntry('');
    setTp('');
    setSl('');
    setRrr('');
    setPnl('');
    setNotes('');
    setTagInput('');
    setCustomMistake('');
    setFormImages({ entry: null, during: null, exit: null });
    setFormResult('win');
    setFormDirection('buy');
    setFormTags([]);
    setFormMistakes([]);
    setFieldErrors({});
  }, [setFormImages, setFormResult, setFormDirection, setFormTags, setFormMistakes]);

  // Load trade data for editing
  useEffect(() => {
    if (editingTradeId && selDay) {
      const list = monthTrades[String(selDay)] || [];
      const trade = list.find((t) => t.id === editingTradeId);
      if (trade) {
        setPair(trade.pair || 'XAUUSD');
        setLot(trade.lot || '');
        setEntry(trade.entry || '');
        setTp(trade.tp || '');
        setSl(trade.sl || '');
        setRrr(trade.rrr || '');
        setPnl(trade.pnl || '');
        setNotes(trade.notes || '');
        setFormImages({
          entry: trade.images?.entry || null,
          during: trade.images?.during || null,
          exit: trade.images?.exit || null,
        });
        setFormResult(trade.result || 'win');
        setFormDirection(trade.direction || 'buy');
        setFormTags([...(trade.tags || [])]);
        setFormMistakes([...(trade.mistakes || [])]);
        setFieldErrors({});
      }
    } else {
      resetForm();
    }
  }, [editingTradeId, selDay, monthTrades, setFormImages, setFormResult, setFormDirection, setFormTags, setFormMistakes, resetForm]);

  const close = useCallback(() => {
    setTradeModalOpen(false);
    setEditingTradeId(null);
  }, [setTradeModalOpen, setEditingTradeId]);

  // Auto RRR calculation
  const autoRRR = useCallback(() => {
    const e = parseFloat(entry);
    const t = parseFloat(tp);
    const s = parseFloat(sl);
    if (e && t && s && s !== e) {
      const reward = Math.abs(t - e);
      const risk = Math.abs(s - e);
      if (risk > 0) setRrr((reward / risk).toFixed(2));
    }
  }, [entry, tp, sl]);

  useEffect(() => {
    autoRRR();
  }, [entry, tp, sl, autoRRR]);

  // Handle image upload with functional setState (prevents stale closure bug)
  const handleImageUpload = useCallback(
    async (type: TradeImageType, file: File) => {
      try {
        const base64 = await fileToBase64(file);
        setFormImages((prev) => ({ ...prev, [type]: base64 }));
      } catch {
        addToast('Image upload failed', 'e');
      }
    },
    [setFormImages, addToast]
  );

  const removeImage = useCallback(
    (type: TradeImageType) => {
      setFormImages((prev) => ({ ...prev, [type]: null }));
    },
    [setFormImages]
  );

  // Tag handling
  const addTag = useCallback(() => {
    const t = tagInput.trim().replace(/,/g, '');
    if (t && !formTags.includes(t)) {
      setFormTags([...formTags, t]);
    }
    setTagInput('');
  }, [tagInput, formTags, setFormTags]);

  const tagKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
        e.preventDefault();
        addTag();
      }
      if (e.key === 'Backspace' && !tagInput && formTags.length) {
        setFormTags(formTags.slice(0, -1));
      }
    },
    [tagInput, formTags, setFormTags, addTag]
  );

  // Mistake handling
  const toggleMistake = useCallback(
    (m: string) => {
      if (formMistakes.includes(m)) {
        setFormMistakes(formMistakes.filter((x) => x !== m));
      } else {
        setFormMistakes([...formMistakes, m]);
      }
    },
    [formMistakes, setFormMistakes]
  );

  const addCustomMistake = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        const v = customMistake.trim();
        if (v && !formMistakes.includes(v)) {
          setFormMistakes([...formMistakes, v]);
        }
        setCustomMistake('');
      }
    },
    [customMistake, formMistakes, setFormMistakes]
  );

  // Stats preview
  const previewStats = (() => {
    const curP = parseFloat(pnl) || 0;
    const hypo: Record<string, Trade[]> = {};
    Object.entries(monthTrades).forEach(([k, v]) => {
      hypo[k] = (v || []).filter((t) => t.id !== editingTradeId);
    });
    hypo['__cur'] = [{ pnl: String(curP), result: formResult } as Trade];
    return calcStats(Object.values(hypo).flat());
  })();

  // Save trade
  const saveTrade = useCallback(async () => {
    if (!selDay) {
      addToast('Select a day first', 'e');
      return;
    }
    if (saving) return;

    // Validate required fields
    const errors: Record<string, string> = {};
    if (!lot.trim()) errors.lot = 'Required';
    else if (isNaN(parseFloat(lot)) || parseFloat(lot) <= 0) errors.lot = 'Must be a positive number';

    if (!entry.trim()) errors.entry = 'Required';
    else if (isNaN(parseFloat(entry))) errors.entry = 'Must be a number';

    if (!sl.trim()) errors.sl = 'Required';
    else if (isNaN(parseFloat(sl))) errors.sl = 'Must be a number';

    if (!pnl.trim()) errors.pnl = 'Required';
    else if (isNaN(parseFloat(pnl))) errors.pnl = 'Must be a number';

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      addToast('Please fix the highlighted fields', 'e');
      return;
    }
    setFieldErrors({});

    setSaving(true);
    hapticMedium();

    try {
      const trade: Trade = {
        id: editingTradeId || generateTradeId(),
        pair: pair || 'XAUUSD',
        lot,
        direction: formDirection,
        result: formResult,
        entry,
        tp,
        sl,
        rrr,
        pnl,
        tags: [...formTags],
        mistakes: [...formMistakes],
        notes,
        images: { ...formImages },
        savedAt: editingTradeId
          ? (monthTrades[String(selDay)]?.find((t) => t.id === editingTradeId)?.savedAt || Date.now())
          : Date.now(),
      };

      const k = String(selDay);
      const list = monthTrades[k] || [];
      const idx = list.findIndex((t) => t.id === editingTradeId);
      const newList =
        idx >= 0 ? list.map((t, i) => (i === idx ? trade : t)) : [...list, trade];

      const updated = { ...monthTrades, [k]: newList };
      setMonthTrades(updated);
      await saveMonthTrades(year, month, updated);
      close();

      const all = await loadAllTrades();
      setAllTrades(all);

      addToast(editingTradeId ? 'Trade updated \u2713' : 'Trade saved \u2713', 's');
      triggerRefresh();
    } catch {
      addToast('Failed to save trade', 'e');
    } finally {
      setSaving(false);
    }
  }, [
    selDay, editingTradeId, pair, lot, formDirection, formResult,
    entry, tp, sl, rrr, pnl, formTags, formMistakes, notes, formImages,
    monthTrades, year, month, setMonthTrades, close, setAllTrades,
    addToast, triggerRefresh, saving,
  ]);

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && tradeModalOpen) {
        close();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [tradeModalOpen, close]);

  if (!tradeModalOpen) return null;

  const wrColor =
    previewStats.wr !== null && previewStats.wr >= 50 ? 'var(--green)' : 'var(--red)';
  const pfColor =
    parseFloat(previewStats.pf || '0') >= 1.5
      ? 'var(--green)'
      : parseFloat(previewStats.pf || '0') >= 1
        ? 'var(--yellow)'
        : 'var(--red)';

  return (
    <div className="trade-ovl open" onClick={close} role="dialog" aria-modal="true" aria-label={editingTradeId ? 'Edit trade' : 'Log trade'}>
      <div className="tmodal" onClick={(e) => e.stopPropagation()}>
        <div className="tm-head">
          <div className="tm-title">{editingTradeId ? 'Edit Trade' : 'Log Trade'}</div>
          <button className="xbtn" onClick={close} aria-label="Close modal">
            <X size={16} />
          </button>
        </div>

        <div className="tm-body">
          {/* Stats Banner */}
          <div
            className="wrb"
            style={{
              borderColor:
                previewStats.wr !== null && previewStats.wr >= 50
                  ? 'rgba(74,222,128,.26)'
                  : 'rgba(248,113,113,.26)',
            }}
          >
            <div className="wrbg">
              <span className="wlbl">Win Rate</span>
              <span className="wval" style={{ color: wrColor, fontSize: '20px' }}>
                {previewStats.wr !== null ? `${previewStats.wr}%` : '\u2014'}
              </span>
            </div>
            <div className="wrbg" style={{ alignItems: 'flex-end' }}>
              <span className="wlbl">Profit Factor</span>
              <span className="wval" style={{ color: pfColor, fontSize: '16px' }}>
                {previewStats.pf || '\u2014'}
              </span>
            </div>
          </div>

          {/* Form Grid */}
          <div className="fgrid">
            <div className="fi">
              <span className="flbl">Pair</span>
              <input
                className="inp"
                value={pair}
                onChange={(e) => setPair(e.target.value)}
                placeholder="XAUUSD"
                aria-label="Currency pair"
              />
            </div>
            <div className="fi">
              <span className="flbl">Lot Size</span>
              <input
                className={`inp${fieldErrors.lot ? ' inp-error' : ''}`}
                value={lot}
                onChange={(e) => setLot(e.target.value)}
                type="number"
                step="0.01"
                placeholder="0.01"
                aria-label="Lot size"
                aria-invalid={!!fieldErrors.lot}
              />
              {fieldErrors.lot && <span className="ferr">{fieldErrors.lot}</span>}
            </div>

            {/* Result Toggle */}
            <div className="fi full">
              <span className="flbl">Result</span>
              <div className="trow" role="radiogroup" aria-label="Trade result">
                <button
                  className={`tbtn tw${formResult === 'win' ? ' on' : ''}`}
                  onClick={() => setFormResult('win')}
                  role="radio"
                  aria-checked={formResult === 'win'}
                >
                  <Check size={10} /> WIN
                </button>
                <button
                  className={`tbtn tl${formResult === 'loss' ? ' on' : ''}`}
                  onClick={() => setFormResult('loss')}
                  role="radio"
                  aria-checked={formResult === 'loss'}
                >
                  <X size={10} /> LOSS
                </button>
                <button
                  className={`tbtn tbe${formResult === 'be' ? ' on' : ''}`}
                  onClick={() => setFormResult('be')}
                  role="radio"
                  aria-checked={formResult === 'be'}
                >
                  &#126; B/E
                </button>
              </div>
            </div>

            {/* Direction Toggle */}
            <div className="fi full">
              <span className="flbl">Direction</span>
              <div className="trow" role="radiogroup" aria-label="Trade direction">
                <button
                  className={`tbtn tbu${formDirection === 'buy' ? ' on' : ''}`}
                  onClick={() => setFormDirection('buy')}
                  role="radio"
                  aria-checked={formDirection === 'buy'}
                >
                  BUY
                </button>
                <button
                  className={`tbtn tsl${formDirection === 'sell' ? ' on' : ''}`}
                  onClick={() => setFormDirection('sell')}
                  role="radio"
                  aria-checked={formDirection === 'sell'}
                >
                  SELL
                </button>
              </div>
            </div>

            <div className="fi">
              <span className="flbl">Entry</span>
              <input
                className={`inp${fieldErrors.entry ? ' inp-error' : ''}`}
                value={entry}
                onChange={(e) => setEntry(e.target.value)}
                type="number"
                step="0.01"
                placeholder="2320.50"
                aria-label="Entry price"
                aria-invalid={!!fieldErrors.entry}
              />
              {fieldErrors.entry && <span className="ferr">{fieldErrors.entry}</span>}
            </div>
            <div className="fi">
              <span className="flbl">Take Profit</span>
              <input
                className="inp"
                value={tp}
                onChange={(e) => setTp(e.target.value)}
                type="number"
                step="0.01"
                placeholder="2340.00"
                aria-label="Take profit"
              />
            </div>
            <div className="fi">
              <span className="flbl">Stop Loss</span>
              <input
                className={`inp${fieldErrors.sl ? ' inp-error' : ''}`}
                value={sl}
                onChange={(e) => setSl(e.target.value)}
                type="number"
                step="0.01"
                placeholder="2310.00"
                aria-label="Stop loss"
                aria-invalid={!!fieldErrors.sl}
              />
              {fieldErrors.sl && <span className="ferr">{fieldErrors.sl}</span>}
            </div>
            <div className="fi">
              <span className="flbl">RRR (auto)</span>
              <input
                className="inp inp-rrr"
                value={rrr}
                onChange={(e) => setRrr(e.target.value)}
                placeholder="Auto"
                readOnly
                title="Calculated automatically from Entry, Take Profit, and Stop Loss"
                aria-label="Risk reward ratio (auto calculated from entry, take profit, and stop loss)"
              />
            </div>

            {/* P&L */}
            <div className="fi full">
              <span className="flbl">P&amp;L ($)</span>
              <div className="pnlrow">
                <button
                  type="button"
                  className={`sgnbtn sgp${(parseFloat(pnl) || 0) >= 0 ? ' on' : ''}`}
                  onClick={() => setPnl(String(Math.abs(parseFloat(pnl) || 0)))}
                  aria-label="Make positive"
                >
                  <Plus size={16} />
                </button>
                <button
                  type="button"
                  className={`sgnbtn sgm${(parseFloat(pnl) || 0) < 0 ? ' on' : ''}`}
                  onClick={() => setPnl(String(-Math.abs(parseFloat(pnl) || 0)))}
                  aria-label="Make negative"
                >
                  <Minus size={16} />
                </button>
                <input
                  className={`inp${fieldErrors.pnl ? ' inp-error' : ''}`}
                  value={pnl}
                  onChange={(e) => setPnl(e.target.value)}
                  type="number"
                  step="0.01"
                  placeholder="150.00"
                  style={{ flex: 1, minWidth: 0 }}
                  aria-label="Profit or loss amount"
                  aria-invalid={!!fieldErrors.pnl}
                />
              </div>
              {fieldErrors.pnl && <span className="ferr">{fieldErrors.pnl}</span>}
            </div>

            {/* Mistakes */}
            <div className="fi full">
              <span className="flbl">Mistakes</span>
              <div className="mgrid" role="group" aria-label="Trade mistakes">
                {MISTAKES_LIST.map((m) => (
                  <button
                    key={m}
                    className={`mbtn${formMistakes.includes(m) ? ' on' : ''}`}
                    onClick={() => toggleMistake(m)}
                    aria-pressed={formMistakes.includes(m)}
                  >
                    {m}
                  </button>
                ))}
              </div>
              <input
                className="inp"
                value={customMistake}
                onChange={(e) => setCustomMistake(e.target.value)}
                onKeyDown={addCustomMistake}
                placeholder="Custom mistake + Enter"
                style={{ marginTop: '5px' }}
                aria-label="Custom mistake"
              />
            </div>

            {/* Tags */}
            <div className="fi full">
              <span className="flbl">Tags</span>
              <div
                className="twrap"
                onClick={() => document.getElementById('tinp')?.focus()}
              >
                {formTags.map((tg, i) => (
                  <span key={tg} className="tchip">
                    {tg}
                    <button
                      onClick={() => setFormTags(formTags.filter((_, idx) => idx !== i))}
                      aria-label={`Remove tag ${tg}`}
                    >
                      &#215;
                    </button>
                  </span>
                ))}
                <input
                  id="tinp"
                  className="tinp"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={tagKeyDown}
                  placeholder={formTags.length ? '' : 'Type & Enter...'}
                  aria-label="Add tag"
                />
              </div>
            </div>

            {/* Notes */}
            <div className="fi full">
              <span className="flbl">Notes</span>
              <textarea
                className="inp"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Setup, confluences, emotions..."
                aria-label="Trade notes"
              />
            </div>
          </div>

          {/* Image Upload — BUG FIX: Consistent type-safe IDs */}
          <div className="isec">
            <div className="istitle">Chart Screenshots</div>
            <div className="iups">
              {(['entry', 'during', 'exit'] as TradeImageType[]).map((type) => {
                const config = IMAGE_TYPE_CONFIG[type];
                const img = formImages[type];
                return (
                  <div className="ibox" key={type}>
                    <div className="iblbl" style={{ color: `var(${config.colorVar})` }}>
                      {config.label}
                    </div>
                    {img ? (
                      <div className="uprev">
                        <img
                          src={img}
                          onClick={() => {
                            setLightboxSrc(img);
                            setLightboxLabel(`${config.label} Chart`);
                            setLightboxOpen(true);
                          }}
                          alt={`${config.label} screenshot`}
                          style={{ cursor: 'zoom-in' }}
                        />
                        <button
                          className="urmv"
                          onClick={() => removeImage(type)}
                          aria-label={`Remove ${config.label} image`}
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ) : (
                      <label className="uarea">
                        <span className="uplus">+</span>
                        <small>Upload</small>
                        <input
                          type="file"
                          accept="image/*"
                          style={{ display: 'none' }}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) handleImageUpload(type, f);
                            e.target.value = '';
                          }}
                          aria-label={`Upload ${config.label} screenshot`}
                        />
                      </label>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="tm-foot">
          <button className="ccbtn" onClick={close} aria-label="Cancel">
            Cancel
          </button>
          <button
            className="svbtn"
            onClick={saveTrade}
            disabled={saving}
            aria-label={editingTradeId ? 'Update trade' : 'Save trade'}
          >
            {saving ? 'Saving...' : editingTradeId ? 'Update Trade' : 'Save Trade'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default memo(TradeModal);
