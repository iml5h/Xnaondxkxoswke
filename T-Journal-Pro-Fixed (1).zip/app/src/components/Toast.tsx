import { memo, useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';

function ToastContainer() {
  const { toasts } = useStore();
  const exitingRef = useRef<Set<string>>(new Set());

  // Track exiting toasts for exit animation
  useEffect(() => {
    const currentIds = new Set(toasts.map((t) => t.id));
    // Clean up exiting set for toasts that are gone
    exitingRef.current.forEach((id) => {
      if (currentIds.has(id)) exitingRef.current.delete(id);
    });
  }, [toasts]);

  return (
    <div className="toast-container" role="region" aria-label="Notifications">
      {toasts.map((t) => {
        const isSuccess = t.type === 's';
        const isError = t.type === 'e';
        return (
          <div
            key={t.id}
            className={`toast toast-${isSuccess ? 'success' : isError ? 'error' : 'info'}`}
            role="status"
            aria-live="polite"
          >
            <span aria-hidden="true">{isSuccess ? '\u2713' : isError ? '\u2717' : '\u25C6'}</span>
            <span>{t.msg}</span>
          </div>
        );
      })}
    </div>
  );
}

export default memo(ToastContainer);
