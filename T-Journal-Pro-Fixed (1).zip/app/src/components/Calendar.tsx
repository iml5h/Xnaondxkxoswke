import { useCallback, memo } from 'react';
import { MONTHS, DAYS_S } from '@/types';
import { dayStats, hasNote, fmtSmart, fmtFull } from '@/lib/utils';
import type { Trade, NoteData } from '@/types';
import { hapticLight } from '@/lib/utils';

interface Props {
  year: number;
  month: number;
  trades: Record<string, Trade[]>;
  notes: Record<string, NoteData>;
  onDayClick: (day: number) => void;
  onMonthChange: (y: number, m: number) => void;
}

function Calendar({ year, month, trades, notes, onDayClick, onMonthChange }: Props) {
  const now = new Date();

  const prevMonth = useCallback(() => {
    if (month === 0) onMonthChange(year - 1, 11);
    else onMonthChange(year, month - 1);
  }, [year, month, onMonthChange]);

  const nextMonth = useCallback(() => {
    if (month === 11) onMonthChange(year + 1, 0);
    else onMonthChange(year, month + 1);
  }, [year, month, onMonthChange]);

  const totalDays = new Date(year, month + 1, 0).getDate();
  const offset = new Date(year, month, 1).getDay();
  const cells: (number | null)[] = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const handleDayClick = (d: number) => {
    hapticLight();
    onDayClick(d);
  };

  return (
    <div className="cal-section">
      <div className="cal-head">
        <div className="cal-title">{MONTHS[month]} {year}</div>
        <div className="cal-arrows">
          <button
            className="car-btn"
            onClick={prevMonth}
            aria-label="Previous month"
          >
            &#8249;
          </button>
          <button
            className="car-btn"
            onClick={nextMonth}
            aria-label="Next month"
          >
            &#8250;
          </button>
        </div>
      </div>

      <div className="cal-grid" role="rowgroup">
        {DAYS_S.map((d, i) => (
          <div key={i} className="dlbl" role="columnheader">
            {d}
          </div>
        ))}
      </div>

      <div className="cal-grid" id="calgrid">
        {cells.map((d, i) => {
          if (!d) return <div key={`e-${i}`} className="cal-cell-empty" aria-hidden="true" />;

          const { count, pnl } = dayStats(String(d), trades);
          const isToday = d === now.getDate() && month === now.getMonth() && year === now.getFullYear();
          const note = hasNote(String(d), notes);

          let cls = 'cal-cell';
          if (isToday) cls += ' today';
          if (count > 0) cls += pnl > 0 ? ' pro' : pnl < 0 ? ' los' : ' eve';
          if (note) cls += ' has-note';

          const pnlColor = pnl > 0 ? 'var(--green)' : pnl < 0 ? 'var(--red)' : 'rgba(255,255,255,.35)';

          return (
            <div
              key={d}
              className={cls}
              onClick={() => handleDayClick(d)}
              role="gridcell"
              aria-label={`${MONTHS[month]} ${d}: ${count > 0 ? `${count} trade${count !== 1 ? 's' : ''}, ${fmtFull(pnl)}` : 'No trades'}`}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleDayClick(d);
                }
              }}
            >
              {count > 0 && (
                <div className="cal-tooltip" aria-hidden="true">
                  {fmtFull(pnl)} &middot; {count} trade{count !== 1 ? 's' : ''}
                </div>
              )}
              <span className="cal-day-num">{d}</span>
              {count > 0 ? (
                <>
                  <span className="cal-day-pnl" style={{ color: pnlColor }}>
                    {fmtSmart(pnl)}
                  </span>
                  <span className="cal-day-count">{count}t</span>
                </>
              ) : (
                <span style={{ fontSize: '10px', opacity: 0.15 }}>&#8212;</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default memo(Calendar);
