import { memo } from 'react';
import { useStore } from '@/store/useStore';
import type { PageName } from '@/types';
import { LayoutGrid, BarChart3, TrendingUp, Settings } from 'lucide-react';
import { hapticLight } from '@/lib/utils';

const PAGES: { key: PageName; label: string; Icon: React.ComponentType<{ size?: number; strokeWidth?: number }> }[] = [
  { key: 'dashboard', label: 'Dashboard', Icon: LayoutGrid },
  { key: 'trades', label: 'Trades', Icon: BarChart3 },
  { key: 'report', label: 'Report', Icon: TrendingUp },
  { key: 'settings', label: 'Settings', Icon: Settings },
];

function BottomNav() {
  const { curPage, setCurPage } = useStore();

  const handleClick = (key: PageName) => {
    hapticLight();
    setCurPage(key);
  };

  return (
    <nav className="bnav" role="navigation" aria-label="Main navigation">
      {PAGES.map((p) => (
        <button
          key={p.key}
          className={`nbtab${curPage === p.key ? ' on' : ''}`}
          onClick={() => handleClick(p.key)}
          aria-label={p.label}
          aria-current={curPage === p.key ? 'page' : undefined}
          role="tab"
        >
          <div className="ico-pill">
            <p.Icon size={22} strokeWidth={1.6} />
          </div>
          <span className="nb-lbl">{p.label}</span>
        </button>
      ))}
    </nav>
  );
}

export default memo(BottomNav);
