import { useEffect, useRef, useState, memo } from 'react';

interface Props {
  onComplete: () => void;
}

function LoadingScreen({ onComplete }: Props) {
  const fillRef = useRef<HTMLDivElement>(null);
  const screenRef = useRef<HTMLDivElement>(null);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => {
      fillRef.current?.classList.add('full');
    }, 200);

    const t2 = setTimeout(() => {
      setFading(true);
    }, 1000);

    const t3 = setTimeout(() => {
      onComplete();
    }, 1450);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onComplete]);

  return (
    <div ref={screenRef} className={`loading-screen${fading ? ' fade-out' : ''}`}>
      <div className="loading-logo">
        <span className="loading-mark">&#9670;</span>
        <span className="loading-text">T-JOURNAL</span>
      </div>
      <div className="loading-track">
        <div ref={fillRef} className="loading-fill" />
      </div>
    </div>
  );
}

export default memo(LoadingScreen);
