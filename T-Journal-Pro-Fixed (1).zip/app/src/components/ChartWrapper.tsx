import { useEffect, useRef, memo } from 'react';
import {
  Chart,
  LineController,
  BarController,
  DoughnutController,
  LineElement,
  BarElement,
  ArcElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip,
  Filler,
} from 'chart.js';
import { chartTextStyle, chartGridColor } from '@/lib/utils';

// Register only the chart types and plugins actually used in the app
// (line, bar, doughnut) instead of pulling in chart.js/auto, which
// registers every controller/element/plugin chart.js ships with.
Chart.register(
  LineController,
  BarController,
  DoughnutController,
  LineElement,
  BarElement,
  ArcElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip,
  Filler
);

interface Props {
  id: string;
  type: string;
  data: object;
  options?: object;
  height?: string;
}

function ChartWrapper({ id, type, data, options, height = '150px' }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Destroy this instance's previous chart before creating a new one
    if (chartRef.current) {
      chartRef.current.destroy();
      chartRef.current = null;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const defaultOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: chartTextStyle },
        y: { grid: { color: chartGridColor }, ticks: chartTextStyle },
      },
      animation: { duration: 800, easing: 'easeOutQuart' as const },
    };

    chartRef.current = new Chart(ctx, {
      type: type as never,
      data: data as never,
      options: { ...defaultOptions, ...options } as never,
    });

    return () => {
      chartRef.current?.destroy();
      chartRef.current = null;
    };
  }, [id, type, data, options]);

  return (
    <div style={{ position: 'relative', height }}>
      <canvas
        ref={canvasRef}
        id={id}
        role="img"
        aria-label={`Chart: ${id}`}
      />
    </div>
  );
}

export default memo(ChartWrapper);
