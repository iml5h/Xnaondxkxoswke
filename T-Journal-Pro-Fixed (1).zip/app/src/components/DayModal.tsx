import { useCallback, useEffect, useState, memo } from 'react';
import { useStore } from '@/store/useStore';
import { loadNote, saveNote } from '@/lib/db';
import { calcStats, fmt, hapticLight } from '@/lib/utils';
import { X, Plus, BookOpen, TrendingUp } from 'lucide-react';

function DayModal() {
  const {
    dayModalOpen, setDayModalOpen,
    dayModalTab, setDayModalTab,
    year, month, selDay,
    monthTrades,
    setTradeModalOpen, setEditingTradeId,
    addToast,
  } = useStore();

  const [noteText, setNoteText] = useState('');
  const [noteImages, setNoteImages] = useState<string[]>([]);
  const [savingNote, setSavingNote] = useState(false);

  // Load note when modal opens
  useEffect(() => {
    if (dayModalOpen && selDay !== null) {
      loadNote(year, month, selDay).then((note) => {
        setNoteText(note.text || '');
        setNoteImages([...(note.images || [])]);
      });
      setDayModalTab('t');
    }
  }, [dayModalOpen, selDay, year, month, setDayModalTab]);

  const trades = selDay !== null ? (monthTrades[String(selDay)] || []) : [];
  const stats = calcStats(trades);

  const close = useCallback(() => {
    setDayModalOpen(false);
  }, [setDayModalOpen]);

  const saveNoteData = useCallback(async () => {
    if (selDay === null) return;
    setSavingNote(true);
    try {
      await saveNote(year, month, selDay, { text: noteText, images: noteImages });
      addToast('Note saved \u2713', 's');
    } catch {
      addToast('Failed to save note', 'e');
    } finally {
      setSavingNote(false);
    }
  }, [selDay, year, month, noteText, noteImages, addToast]);

  const addNoteImage = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) setNoteImages((prev) => [...prev, result]);
    };
    reader.readAsDataURL(file);
  }, []);

  const removeNoteImage = useCallback((i: number) => {
    setNoteImages((prev) => prev.filter((_, idx) => idx !== i));
  }, []);

  const openNew = useCallback(() => {
    hapticLight();
    setEditingTradeId(null);
    setTradeModalOpen(true);
    close();
  }, [setEditingTradeId, setTradeModalOpen, close]);

  const openEdit = useCallback(
    (id: number) => {
      hapticLight();
      setEditingTradeId(id);
      setTradeModalOpen(true);
      close();
    },
    [setEditingTradeId, setTradeModalOpen, close]
  );

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dayModalOpen) {
        close();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [dayModalOpen, close]);

  if (!dayModalOpen || selDay === null) return null;

  const date = new Date(year, month, selDay);
  const dateStr = date.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div
      className="day-modal open"
      onClick={close}
      role="dialog"
      aria-modal="true"
      aria-label={`Trades for ${dateStr}`}
    >
      <div className="dm-card" onClick={(e) => e.stopPropagation()}>
        <div className="dm-head">
          <div className="dm-title-row">
            <div className="dm-title">{dateStr}</div>
            <button className="xbtn" onClick={close} aria-label="Close">
              <X size={16} />
            </button>
          </div>
          <div className="dm-stats">
            <div className="dm-stat">
              <span className="dm-s-lbl">P&L</span>
              <span
                className="dm-s-val"
                style={{
                  color:
                    stats.pnl > 0 ? 'var(--green)' : stats.pnl < 0 ? 'var(--red)' : 'var(--t3)',
                }}
              >
                {fmt(stats.pnl)}
              </span>
            </div>
            <div className="dm-stat">
              <span className="dm-s-lbl">Trades</span>
              <span className="dm-s-val">{stats.total}</span>
            </div>
            {stats.wr !== null && (
              <div className="dm-stat">
                <span className="dm-s-lbl">Win Rate</span>
                <span
                  className="dm-s-val"
                  style={{ color: stats.wr >= 50 ? 'var(--green)' : 'var(--red)' }}
                >
                  {stats.wr}%
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="dm-tabs" role="tablist">
          <button
            className={`dm-tab${dayModalTab === 't' ? ' on' : ''}`}
            onClick={() => setDayModalTab('t')}
            role="tab"
            aria-selected={dayModalTab === 't'}
            aria-label="Trades tab"
          >
            <TrendingUp size={14} style={{ marginRight: '4px', display: 'inline', verticalAlign: 'text-bottom' }} />
            Trades
          </button>
          <button
            className={`dm-tab${dayModalTab === 'n' ? ' on' : ''}`}
            onClick={() => setDayModalTab('n')}
            role="tab"
            aria-selected={dayModalTab === 'n'}
            aria-label="Notes tab"
          >
            <BookOpen size={14} style={{ marginRight: '4px', display: 'inline', verticalAlign: 'text-bottom' }} />
            Notes
          </button>
        </div>

        <div className="dm-body">
          {dayModalTab === 't' ? (
            <div className="dm-trades">
              {trades.length === 0 ? (
                <div className="dm-empty">
                  No trades yet.
                  <br />
                  Tap "Add Trade" to start.
                </div>
              ) : (
                trades.map((t) => {
                  const pnl = parseFloat(t.pnl) || 0;
                  const pc = pnl > 0 ? 'var(--green)' : pnl < 0 ? 'var(--red)' : 'var(--t3)';
                  let rb: string, rl: string;
                  if (t.result === 'be') {
                    rb = 'bbe';
                    rl = 'B/E';
                  } else if (pnl > 0) {
                    rb = 'bwin';
                    rl = 'WIN';
                  } else if (pnl < 0) {
                    rb = 'blos';
                    rl = 'LOSS';
                  } else {
                    rb = 'bbe';
                    rl = 'B/E';
                  }

                  return (
                    <div
                      key={t.id}
                      className="dm-tcard"
                      onClick={() => openEdit(t.id)}
                      style={{ cursor: 'pointer' }}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          openEdit(t.id);
                        }
                      }}
                    >
                      <div className="dm-tc-left">
                        <span className={`badge ${t.direction === 'sell' ? 'bsell' : 'bbuy'}`}>
                          {t.direction === 'sell' ? '\u25BC' : '\u25B2'} {t.pair || '\u2014'}
                        </span>
                        <span className={`badge ${rb}`}>{rl}</span>
                        {t.rrr && (
                          <span style={{ fontSize: '10px', color: 'var(--t3)' }}>RRR {t.rrr}</span>
                        )}
                      </div>
                      <span className="dm-tc-pnl" style={{ color: pc }}>
                        {fmt(pnl)}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          ) : (
            <div className="nbook">
              <textarea
                className="nbtxt"
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder="&#9997;&#65039; Daily plan, analysis, emotions, watchlist..."
                aria-label="Daily note"
              />
              <div className="nbimgs">
                {noteImages.map((img, i) => (
                  <div key={i} className="nbit">
                    <img src={img} alt={`Note image ${i + 1}`} />
                    <button
                      className="nbrmv"
                      onClick={() => removeNoteImage(i)}
                      aria-label={`Remove image ${i + 1}`}
                    >
                      <X size={10} />
                    </button>
                  </div>
                ))}
                <label className="nbadd">
                  <span style={{ fontSize: '17px', opacity: 0.35 }}>+</span>
                  <span>Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) addNoteImage(f);
                      e.target.value = '';
                    }}
                    aria-label="Add photo"
                  />
                </label>
              </div>
              <button
                className="nbsave"
                onClick={saveNoteData}
                disabled={savingNote}
                aria-label="Save note"
              >
                {savingNote ? 'Saving...' : 'Save Note'}
              </button>
            </div>
          )}
        </div>

        {dayModalTab === 't' && (
          <div className="dm-foot">
            <button className="dm-add-btn" onClick={openNew} aria-label="Add new trade">
              <Plus size={16} />
              Add Trade
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default memo(DayModal);
