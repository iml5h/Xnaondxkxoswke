import { useState, memo } from 'react';
import { useStore } from '@/store/useStore';
import { deleteAllData } from '@/lib/db';
import { Trash2, ArrowLeft, AlertTriangle } from 'lucide-react';

function ResetModal() {
  const {
    resetModalOpen, setResetModalOpen,
    addToast, triggerRefresh,
    setMonthTrades, setAllTrades,
  } = useStore();

  const [deleting, setDeleting] = useState(false);

  const close = () => setResetModalOpen(false);

  const doReset = async () => {
    if (deleting) return;
    setDeleting(true);
    try {
      await deleteAllData();
      setMonthTrades({});
      setAllTrades([]);
      close();
      triggerRefresh();
      addToast('All data deleted', 'i');
    } catch {
      addToast('Reset failed', 'e');
    } finally {
      setDeleting(false);
    }
  };

  if (!resetModalOpen) return null;

  return (
    <div
      className="reset-ovl open"
      onClick={close}
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="reset-title"
      aria-describedby="reset-desc"
    >
      <div className="reset-modal" onClick={(e) => e.stopPropagation()}>
        <div className="rm-title" id="reset-title">
          <AlertTriangle size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'text-bottom' }} />
          Reset All Data
        </div>
        <div className="rm-desc" id="reset-desc">
          This will <strong style={{ color: 'var(--red)' }}>permanently delete</strong> all your trades and notes.
          Consider exporting a backup first. This action cannot be undone.
        </div>
        <div className="rm-opts">
          <button
            className="rm-btn rm-btn-del"
            onClick={doReset}
            disabled={deleting}
            aria-label="Delete all data permanently"
          >
            <Trash2 size={18} />
            <div>
              <div>{deleting ? 'Deleting...' : 'Delete Everything'}</div>
              <div style={{ fontSize: '10px', fontWeight: 400, opacity: 0.6, marginTop: '2px' }}>
                This cannot be undone
              </div>
            </div>
          </button>
          <button
            className="rm-btn rm-btn-cancel"
            onClick={close}
            aria-label="Cancel reset"
          >
            <ArrowLeft size={18} />
            <div>Cancel</div>
          </button>
        </div>
      </div>
    </div>
  );
}

export default memo(ResetModal);
