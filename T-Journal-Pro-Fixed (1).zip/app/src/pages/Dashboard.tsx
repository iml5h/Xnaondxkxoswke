import { useEffect, useRef, useMemo, useState, useCallback, memo } from 'react';
import { useStore } from '@/store/useStore';
import { loadMonthTrades, loadMonthNotes, dkeys } from '@/lib/db';
import { calcStats, fmt, formatDateLong } from '@/lib/utils';
import { DAYS_S } from '@/types';
import type { Trade } from '@/types';
import Calendar from '@/components/Calendar';
import ChartWrapper from '@/components/ChartWrapper';
import { TrendingUp, BarChart3, PieChart, AlertCircle } from 'lucide-react';

function Dashboard() {
  const {
    year, month, setYear, setMonth,
    monthTrades, setMonthTrades,
    notes, setNotes,
    setSelDay, setDayModalOpen, setDayModalTab,
    refresh,
  } = useStore();

  const [allTrades, setAllTrades] = useState<Trade[]>([]);
  const [visible, setVisible] = useState(false);
  const hasAnimated = useRef(false);

  // Load all trades for equity curve, stats, analytics
  useEffect(() => {
    async function loadAllTradesForStats() {
      try {
        const keys = await dkeys('months');
        const arr: Trade[] = [];
        const promises = keys.map(async (k) => {
          const keyStr = String(k).replace('t:', '');
          const [y, m] = keyStr.split('-').map(Number);
          if (!isNaN(y) && !isNaN(m)) {
            const monthData = await loadMonthTrades(y, m);
            if (monthData && typeof monthData === 'object' && !Array.isArray(monthData)) {
              Object.values(monthData).forEach((dayTrades: unknown) => {
                const ts = dayTrades as Trade[];
                if (Array.isArray(ts)) {
                  ts.forEach((t) => arr.push(t));
                }
              });
            }
          }
        });
        await Promise.all(promises);
        arr.sort((a, b) => (a.savedAt || 0) - (b.savedAt || 0));
        setAllTrades(arr);
      } catch (e) {
        console.error('Failed to load trades:', e);
      }
    }
    loadAllTradesForStats();
  }, [refresh]);

  // Load month trades for calendar
  useEffect(() => {
    loadMonthTrades(year, month).then((data) => {
      setMonthTrades(data || {});
      // Load notes in parallel
      loadMonthNotes(year, month).then((noteData) => {
        setNotes(noteData);
      });
    });
  }, [year, month, setMonthTrades, setNotes, refresh]);

  // Entrance animation - only animate once on mount
  useEffect(() => {
    if (!hasAnimated.current) {
      hasAnimated.current = true;
      requestAnimationFrame(() => {
        setVisible(true);
      });
    }
  }, []);

  const stats = useMemo(() => calcStats(allTrades), [allTrades]);

  const handleDayClick = useCallback(
    (day: number) => {
      setSelDay(day);
      setDayModalTab('t');
      setDayModalOpen(true);
    },
    [setSelDay, setDayModalTab, setDayModalOpen]
  );

  const handleMonthChange = useCallback(
    (y: number, m: number) => {
      setYear(y);
      setMonth(m);
      setNotes({});
    },
    [setYear, setMonth, setNotes]
  );

  const dateStr = formatDateLong(new Date());

  // Equity curve data
  const equityData = useMemo(() => {
    if (!allTrades.length) return null;
    let cum = 0;
    const labels: string[] = [];
    const data: number[] = [];
    allTrades.forEach((t, i) => {
      cum += parseFloat(t.pnl) || 0;
      labels.push(String(i + 1));
      data.push(parseFloat(cum.toFixed(2)));
    });
    return { labels, data, cum };
  }, [allTrades]);

  // P&L by Day of Week
  const dowData = useMemo(() => {
    const dow = new Array(7).fill(0);
    allTrades.forEach((t) => {
      const d = new Date(t.savedAt || Date.now()).getDay();
      dow[d] += parseFloat(t.pnl) || 0;
    });
    return {
      labels: DAYS_S,
      datasets: [
        {
          data: dow.map((v) => parseFloat(v.toFixed(2))),
          backgroundColor: dow.map((v) =>
            v >= 0 ? 'rgba(74,222,128,.65)' : 'rgba(248,113,113,.65)'
          ),
          borderRadius: 4,
        },
      ],
    };
  }, [allTrades]);

  // BUY vs SELL
  const dirData = useMemo(() => {
    const buys = allTrades.filter((t) => t.direction === 'buy').length;
    const sells = allTrades.filter((t) => t.direction === 'sell').length;
    if (!buys && !sells) return null;
    return {
      labels: [`BUY (${buys})`, `SELL (${sells})`],
      datasets: [
        {
          data: [Math.max(buys, 0.01), Math.max(sells, 0.01)],
          backgroundColor: ['rgba(74,222,128,.75)', 'rgba(248,113,113,.75)'],
          borderWidth: 0,
        },
      ],
    };
  }, [allTrades]);

  // Setup / Tag Performance
  const tagData = useMemo(() => {
    const tMap: Record<string, number> = {};
    allTrades.forEach((t) =>
      (t.tags || []).forEach((tg) => {
        if (!tMap[tg]) tMap[tg] = 0;
        tMap[tg] += parseFloat(t.pnl) || 0;
      })
    );
    const tS = Object.entries(tMap)
      .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
      .slice(0, 6);
    if (!tS.length) return null;
    return {
      labels: tS.map(([t]) => t),
      datasets: [
        {
          data: tS.map(([, v]) => parseFloat(v.toFixed(2))),
          backgroundColor: tS.map(([, v]) =>
            v >= 0 ? 'rgba(74,222,128,.65)' : 'rgba(248,113,113,.65)'
          ),
          borderRadius: 4,
        },
      ],
    };
  }, [allTrades]);

  // Mistake Cost
  const mistakeData = useMemo(() => {
    const mMap: Record<string, number> = {};
    allTrades.forEach((t) =>
      (t.mistakes || []).forEach((m) => {
        if (!mMap[m]) mMap[m] = 0;
        mMap[m] += parseFloat(t.pnl) || 0;
      })
    );
    const mS = Object.entries(mMap)
      .sort((a, b) => a[1] - b[1])
      .slice(0, 6);
    if (!mS.length) return null;
    return {
      labels: mS.map(([m]) => m),
      datasets: [
        {
          data: mS.map(([, v]) => parseFloat(v.toFixed(2))),
          backgroundColor: mS.map(([, v]) =>
            v >= 0 ? 'rgba(74,222,128,.65)' : 'rgba(248,113,113,.65)'
          ),
          borderRadius: 4,
        },
      ],
    };
  }, [allTrades]);

  // Statistics list
  const statItems = [
    { key: 'No. of Trades', val: String(stats.total) },
    { key: 'Total Lots', val: stats.lots },
    {
      key: 'Win Rate',
      val: stats.wr !== null ? `${stats.wr}%` : '\u2014',
      col: stats.wr !== null && stats.wr >= 50 ? 'var(--green)' : 'var(--red)',
    },
    {
      key: 'Best Trade',
      val: stats.best !== null && stats.best > 0 ? `$${stats.best.toFixed(2)}` : '\u2014',
      col: 'var(--green)',
    },
    {
      key: 'Average Win',
      val: stats.avgW !== null ? `$${stats.avgW.toFixed(2)}` : '\u2014',
      col: 'var(--green)',
    },
    {
      key: 'Average Loss',
      val: stats.avgL !== null ? `-$${stats.avgL.toFixed(2)}` : '\u2014',
      col: 'var(--red)',
    },
    { key: 'Average RRR', val: stats.avgRRR || '\u2014' },
    {
      key: 'Expectancy',
      val: stats.exp !== null ? `$${stats.exp.toFixed(2)}` : '\u2014',
      col: stats.exp !== null && stats.exp > 0 ? 'var(--green)' : 'var(--red)',
    },
    {
      key: 'Profit Factor',
      val: stats.pf || '\u2014',
      col:
        parseFloat(stats.pf || '0') >= 1.5
          ? 'var(--green)'
          : parseFloat(stats.pf || '0') >= 1
            ? 'var(--yellow)'
            : 'var(--red)',
    },
    { key: 'Gross Profit', val: `$${stats.gP.toFixed(2)}`, col: 'var(--green)' },
    { key: 'Gross Loss', val: `-$${stats.gL.toFixed(2)}`, col: 'var(--red)' },
    {
      key: 'Net P&L',
      val: fmt(stats.pnl),
      col: stats.pnl >= 0 ? 'var(--green)' : 'var(--red)',
    },
    ...(stats.streakType
      ? [
          {
            key: 'Current Streak',
            val: `${stats.streak} ${stats.streakType}`,
            col: stats.streakType === 'W' ? 'var(--green)' : 'var(--red)',
          },
        ]
      : []),
  ];

  const vCls = visible ? ' visible' : '';

  return (
    <div className={`page on${vCls}`} id="pg-dashboard">
      {/* Greeting */}
      <div className="greeting-area">
        <div className="greet-date">{dateStr}</div>
      </div>

      {/* Quick Stats */}
      <div className="qstats">
        {[
          {
            label: 'Net P&L',
            value: fmt(stats.pnl),
            color: stats.pnl >= 0 ? 'var(--green)' : 'var(--red)',
            sub: `${stats.total} trades total`,
            icon: TrendingUp,
          },
          {
            label: 'Win Rate',
            value: stats.wr !== null ? `${stats.wr}%` : '\u2014',
            color: stats.wr !== null && stats.wr >= 50 ? 'var(--green)' : 'var(--red)',
            sub: `${stats.wins}W / ${stats.losses}L`,
            icon: BarChart3,
          },
          {
            label: 'Profit Factor',
            value: stats.pf || '\u2014',
            color:
              parseFloat(stats.pf || '0') >= 1.5
                ? 'var(--green)'
                : parseFloat(stats.pf || '0') >= 1
                  ? 'var(--yellow)'
                  : 'var(--red)',
            sub: 'gross P \u00f7 gross L',
            icon: PieChart,
          },
          {
            label: 'Avg RRR',
            value: stats.avgRRR || '\u2014',
            color: 'var(--t)',
            sub: 'on wins',
            icon: TrendingUp,
          },
        ].map((card, i) => (
          <div
            key={card.label}
            className="qcard tj-card"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? 'translateY(0)' : 'translateY(16px)',
              transition: `opacity 0.5s ease ${i * 0.07}s, transform 0.5s ease ${i * 0.07}s`,
            }}
          >
            <div className="qc-lbl">{card.label}</div>
            <div className="qc-val" style={{ color: card.color }}>
              {card.value}
            </div>
            <div className="qc-sub">{card.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ padding: '0 16px' }}>
        {/* Equity Curve */}
        {equityData ? (
          <div
            className="chart-card tj-card"
            style={{
              marginTop: '16px',
              opacity: visible ? 1 : 0,
              transform: visible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.55s ease, transform 0.55s ease',
            }}
          >
            <div className="cc-head">
              <span className="cc-title">
                <TrendingUp size={12} style={{ display: 'inline', marginRight: '4px', verticalAlign: 'middle' }} />
                Equity Curve
              </span>
              <span className="cc-sub">{allTrades.length} trades</span>
            </div>
            <div style={{ height: '180px' }}>
              <ChartWrapper
                id="eq-curve"
                type="line"
                data={{
                  labels: equityData.labels,
                  datasets: [
                    {
                      data: equityData.data,
                      borderColor:
                        equityData.cum >= 0
                          ? 'rgba(240,192,64,.85)'
                          : 'rgba(248,113,113,.85)',
                      backgroundColor:
                        equityData.cum >= 0
                          ? 'rgba(240,192,64,.08)'
                          : 'rgba(248,113,113,.07)',
                      fill: true,
                      tension: 0.4,
                      pointRadius: 0,
                      pointHoverRadius: 3,
                      borderWidth: 2,
                    },
                  ],
                }}
                options={{
                  plugins: { legend: { display: false } },
                  scales: {
                    x: { display: false },
                    y: { grid: { color: 'rgba(255,255,255,.04)' } },
                  },
                }}
                height="180px"
              />
            </div>
          </div>
        ) : (
          <div
            className="chart-card tj-card"
            style={{
              marginTop: '16px',
              textAlign: 'center',
              padding: '40px',
              color: 'var(--t3)',
            }}
          >
            <AlertCircle size={24} style={{ marginBottom: '8px', opacity: 0.5 }} />
            <div style={{ fontSize: '12px' }}>No trades yet. Add your first trade to see the equity curve.</div>
          </div>
        )}

        {/* Statistics */}
        <div
          className="stats-section"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.5s ease 0.28s, transform 0.5s ease 0.28s',
          }}
        >
          <div className="section-lbl">Statistics</div>
          <div className="tj-card sl-list">
            {statItems.map((s, i) => (
              <div key={i} className="sl-item">
                <span className="sl-key">{s.key}</span>
                <span className="sl-val" style={s.col ? { color: s.col } : {}}>
                  {s.val}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Calendar */}
        <div
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.5s ease 0.35s, transform 0.5s ease 0.35s',
          }}
        >
          <Calendar
            year={year}
            month={month}
            trades={monthTrades}
            notes={notes}
            onDayClick={handleDayClick}
            onMonthChange={handleMonthChange}
          />
        </div>

        {/* Analytics */}
        <div
          className="analytics-section"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.5s ease 0.42s, transform 0.5s ease 0.42s',
          }}
        >
          <div className="section-lbl">Analytics</div>

          {/* P&L by Day */}
          <div className="an-full tj-card">
            <div className="an-title">P&L by Day</div>
            {allTrades.length > 0 ? (
              <div style={{ height: '130px' }}>
                <ChartWrapper id="dow-chart" type="bar" data={dowData} height="130px" />
              </div>
            ) : (
              <div className="empty-state" style={{ padding: '20px' }}>
                <span style={{ fontSize: '11px' }}>No data available</span>
              </div>
            )}
          </div>

          {/* Direction */}
          {dirData && (
            <div className="an-full tj-card">
              <div className="an-title">Direction</div>
              <div style={{ height: '130px' }}>
                <ChartWrapper
                  id="dir-chart"
                  type="doughnut"
                  data={dirData}
                  options={{
                    cutout: '62%',
                    plugins: {
                      legend: {
                        position: 'bottom',
                        labels: {
                          color: 'rgba(232,237,245,.35)',
                          font: { size: 9 },
                          padding: 8,
                        },
                      },
                    },
                  }}
                  height="130px"
                />
              </div>
            </div>
          )}

          {/* Setup Performance */}
          {tagData && (
            <div className="an-full tj-card">
              <div className="an-title">Setup Performance</div>
              <div style={{ height: '140px' }}>
                <ChartWrapper
                  id="tag-chart"
                  type="bar"
                  data={tagData}
                  options={{ indexAxis: 'y' as const }}
                  height="140px"
                />
              </div>
            </div>
          )}

          {/* Mistake Cost */}
          {mistakeData && (
            <div className="an-full tj-card">
              <div className="an-title">Mistake Cost</div>
              <div style={{ height: '130px' }}>
                <ChartWrapper
                  id="mistake-chart"
                  type="bar"
                  data={mistakeData}
                  options={{ indexAxis: 'y' as const }}
                  height="130px"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default memo(Dashboard);
