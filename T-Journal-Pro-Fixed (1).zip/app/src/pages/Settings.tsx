import { useRef, useEffect, memo } from 'react';
import { useStore } from '@/store/useStore';
import { exportAllData, importAllData, loadMonthTrades, loadAllTrades } from '@/lib/db';
import { Download, Upload, Trash2, Settings as SettingsIcon, Shield } from 'lucide-react';

function Settings() {
  const {
    year, month,
    setMonthTrades, setAllTrades,
    setResetModalOpen,
    addToast, triggerRefresh,
  } = useStore();

  const dataSectionRef = useRef<HTMLDivElement>(null);
  const privacySectionRef = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    requestAnimationFrame(() => {
      dataSectionRef.current?.classList.add('visible');
      privacySectionRef.current?.classList.add('visible');
      infoRef.current?.classList.add('visible');
    });
  }, []);

  const exportData = async () => {
    try {
      const data = await exportAllData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `tjournal-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      addToast('Export successful \u2713', 's');
    } catch {
      addToast('Export failed', 'e');
    }
  };

  const importData = (inp: HTMLInputElement) => {
    const file = inp.files?.[0];
    if (!file) return;

    const confirmed = window.confirm(
      'Importing will merge this backup into your current data and may overwrite existing trades with the same dates. Continue?'
    );
    if (!confirmed) {
      inp.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        await importAllData(data);
        const monthData = await loadMonthTrades(year, month);
        setMonthTrades(monthData);
        const all = await loadAllTrades();
        setAllTrades(all);
        triggerRefresh();
        addToast('Import successful \u2713', 's');
      } catch (err) {
        addToast('Import failed: ' + (err as Error).message, 'e');
      }
    };
    reader.readAsText(file);
    inp.value = '';
  };

  return (
    <div className="page on" id="pg-settings">
      <div className="page-content">
        <div className="set-greeting">
          <SettingsIcon size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'text-bottom' }} />
          Settings
        </div>
        <div className="set-sub">Manage your data and preferences</div>

        <div className="set-section" ref={dataSectionRef}>
          <div className="set-sec-lbl">Data Management</div>
          <div className="tj-card">
            <div className="set-item" onClick={exportData} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter') exportData(); }}>
              <div className="si-ico gold">
                <Download size={18} color="rgba(240,192,64,.85)" strokeWidth={1.8} />
              </div>
              <div className="si-content">
                <div className="si-title">Export Data</div>
                <div className="si-sub">Download backup JSON file</div>
              </div>
              <div className="si-arrow">&#8250;</div>
            </div>

            <label className="set-item" style={{ cursor: 'pointer' }}>
              <div className="si-ico green">
                <Upload size={18} color="rgba(74,222,128,.85)" strokeWidth={1.8} />
              </div>
              <div className="si-content">
                <div className="si-title">Import Data</div>
                <div className="si-sub">Restore from backup JSON</div>
              </div>
              <div className="si-arrow">&#8250;</div>
              <input
                type="file"
                accept=".json"
                style={{ display: 'none' }}
                onChange={(e) => importData(e.target)}
                aria-label="Import data from JSON file"
              />
            </label>

            <div
              className="set-item"
              onClick={() => setResetModalOpen(true)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter') setResetModalOpen(true);
              }}
            >
              <div className="si-ico red">
                <Trash2 size={18} color="rgba(248,113,113,.85)" strokeWidth={1.8} />
              </div>
              <div className="si-content">
                <div className="si-title">Reset All Data</div>
                <div className="si-sub">Delete everything permanently</div>
              </div>
              <div className="si-arrow" style={{ color: 'var(--red)' }}>
                &#8250;
              </div>
            </div>
          </div>
        </div>

        {/* Privacy & Security */}
        <div className="set-section" ref={privacySectionRef}>
          <div className="set-sec-lbl">Privacy</div>
          <div className="tj-card">
            <div className="set-item">
              <div className="si-ico" style={{ background: 'rgba(96,165,250,.1)' }}>
                <Shield size={18} color="rgba(96,165,250,.85)" strokeWidth={1.8} />
              </div>
              <div className="si-content">
                <div className="si-title">Local Storage Only</div>
                <div className="si-sub">Your data never leaves your device</div>
              </div>
            </div>
          </div>
        </div>

        <div className="set-info" ref={infoRef}>
          T-Journal Pro
          <br />
          Built for traders, by traders
          <br />
          <span style={{ color: 'var(--t4)' }}>Data stored locally in your browser</span>
        </div>
      </div>
    </div>
  );
}

export default memo(Settings);
