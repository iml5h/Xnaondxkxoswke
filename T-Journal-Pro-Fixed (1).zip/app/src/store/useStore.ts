// ============================================================
// T-Journal Pro — Zustand State Management
// Replaces Context with selective subscriptions for 60fps
// ============================================================

import { create } from 'zustand';
import type { Trade, NoteData, PageName, TradeImages, ToastItem } from '@/types';
import { generateId } from '@/lib/utils';

interface AppState {
  // Navigation
  curPage: PageName;
  setCurPage: (p: PageName) => void;

  // Date
  year: number;
  month: number;
  setYear: (y: number) => void;
  setMonth: (m: number) => void;

  // Trades for current month
  monthTrades: Record<string, Trade[]>;
  setMonthTrades: (t: Record<string, Trade[]>) => void;

  // All trades
  allTrades: Trade[];
  setAllTrades: (t: Trade[]) => void;

  // Selected day
  selDay: number | null;
  setSelDay: (d: number | null) => void;

  // Notes
  notes: Record<string, NoteData>;
  setNotes: (n: Record<string, NoteData>) => void;
  updateNote: (day: string, note: NoteData) => void;

  // Trade Modal
  tradeModalOpen: boolean;
  setTradeModalOpen: (v: boolean) => void;
  editingTradeId: number | null;
  setEditingTradeId: (id: number | null) => void;

  // Day Modal
  dayModalOpen: boolean;
  setDayModalOpen: (v: boolean) => void;
  dayModalTab: 't' | 'n';
  setDayModalTab: (t: 't' | 'n') => void;

  // Reset Modal
  resetModalOpen: boolean;
  setResetModalOpen: (v: boolean) => void;

  // Lightbox
  lightboxOpen: boolean;
  setLightboxOpen: (v: boolean) => void;
  lightboxSrc: string;
  setLightboxSrc: (s: string) => void;
  lightboxLabel: string;
  setLightboxLabel: (s: string) => void;

  // Loading
  loading: boolean;
  setLoading: (v: boolean) => void;

  // Force refresh counter
  refresh: number;
  triggerRefresh: () => void;

  // Trade form state (persisted in modal)
  formImages: TradeImages;
  setFormImages: (i: TradeImages | ((prev: TradeImages) => TradeImages)) => void;
  formResult: 'win' | 'loss' | 'be';
  setFormResult: (r: 'win' | 'loss' | 'be') => void;
  formDirection: 'buy' | 'sell';
  setFormDirection: (d: 'buy' | 'sell') => void;
  formTags: string[];
  setFormTags: (t: string[]) => void;
  formMistakes: string[];
  setFormMistakes: (m: string[]) => void;

  // Toast system
  toasts: ToastItem[];
  addToast: (msg: string, type?: 's' | 'e' | 'i') => void;
  removeToast: (id: string) => void;
}

const now = new Date();

export const useStore = create<AppState>((set) => ({
  // Navigation
  curPage: 'dashboard',
  setCurPage: (p) => set({ curPage: p }),

  // Date
  year: now.getFullYear(),
  month: now.getMonth(),
  setYear: (y) => set({ year: y }),
  setMonth: (m) => set({ month: m }),

  // Trades
  monthTrades: {},
  setMonthTrades: (t) => set({ monthTrades: t }),

  allTrades: [],
  setAllTrades: (t) => set({ allTrades: t }),

  // Selected day
  selDay: null,
  setSelDay: (d) => set({ selDay: d }),

  // Notes
  notes: {},
  setNotes: (n) => set({ notes: n }),
  updateNote: (day, note) =>
    set((state) => ({
      notes: { ...state.notes, [day]: note },
    })),

  // Trade Modal
  tradeModalOpen: false,
  setTradeModalOpen: (v) => set({ tradeModalOpen: v }),
  editingTradeId: null,
  setEditingTradeId: (id) => set({ editingTradeId: id }),

  // Day Modal
  dayModalOpen: false,
  setDayModalOpen: (v) => set({ dayModalOpen: v }),
  dayModalTab: 't',
  setDayModalTab: (t) => set({ dayModalTab: t }),

  // Reset Modal
  resetModalOpen: false,
  setResetModalOpen: (v) => set({ resetModalOpen: v }),

  // Lightbox
  lightboxOpen: false,
  setLightboxOpen: (v) => set({ lightboxOpen: v }),
  lightboxSrc: '',
  setLightboxSrc: (s) => set({ lightboxSrc: s }),
  lightboxLabel: '',
  setLightboxLabel: (s) => set({ lightboxLabel: s }),

  // Loading
  loading: true,
  setLoading: (v) => set({ loading: v }),

  // Refresh
  refresh: 0,
  triggerRefresh: () => set((state) => ({ refresh: state.refresh + 1 })),

  // Form state
  formImages: { entry: null, during: null, exit: null },
  setFormImages: (i) =>
    set((state) => ({
      formImages: typeof i === 'function' ? i(state.formImages) : i,
    })),
  formResult: 'win',
  setFormResult: (r) => set({ formResult: r }),
  formDirection: 'buy',
  setFormDirection: (d) => set({ formDirection: d }),
  formTags: [],
  setFormTags: (t) => set({ formTags: t }),
  formMistakes: [],
  setFormMistakes: (m) => set({ formMistakes: m }),

  // Toast system with proper ID generation and cleanup
  toasts: [],
  addToast: (msg, type = 'i') => {
    const id = generateId();
    set((state) => ({ toasts: [...state.toasts, { id, msg, type }] }));
    // Auto-remove after delay
    setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    }, 3000);
  },
  removeToast: (id) =>
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),
}));
