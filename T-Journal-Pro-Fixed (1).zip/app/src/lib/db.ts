// ============================================================
// T-Journal Pro — IndexedDB Persistence Layer
// Fixed: Race conditions, connection pooling, error recovery
// ============================================================

import type { Trade, NoteData } from '@/types';

const DB_NAME = 'tjournal_pro_v1';
const DB_VERSION = 1;
const STORE_TRADES = 'months';
const STORE_NOTES = 'notes';

let dbInstance: IDBDatabase | null = null;
let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  if (dbInstance) return Promise.resolve(dbInstance);

  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_TRADES)) db.createObjectStore(STORE_TRADES);
      if (!db.objectStoreNames.contains(STORE_NOTES)) db.createObjectStore(STORE_NOTES);
    };

    req.onsuccess = (e) => {
      dbInstance = (e.target as IDBOpenDBRequest).result;
      dbPromise = null;
      resolve(dbInstance);
    };

    req.onerror = (e) => {
      dbPromise = null;
      reject((e.target as IDBOpenDBRequest).error);
    };

    req.onblocked = () => {
      dbPromise = null;
      reject(new Error('Database blocked - close other tabs'));
    };
  });

  return dbPromise;
}

function dbOp<T>(
  store: string,
  mode: IDBTransactionMode,
  fn: (objStore: IDBObjectStore, resolve: (v: T) => void, reject: (e: Event) => void) => void
): Promise<T> {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const tx = db.transaction(store, mode);
      fn(tx.objectStore(store), resolve, reject);
      tx.onerror = (e) => reject(e);
      tx.onabort = (e) => reject(e);
    } catch (e) {
      reject(e);
    }
  });
}

export function dkeys(s: string): Promise<IDBValidKey[]> {
  return dbOp(s, 'readonly', (st, res, rej) => {
    const q = st.getAllKeys();
    q.onsuccess = (e) => res((e.target as IDBRequest).result || []);
    q.onerror = rej;
  });
}

const mk = (y: number, m: number) => `t:${y}-${m}`;
const nk = (y: number, m: number, d: number) => `n:${y}-${m}-${d}`;

// --- Trade Operations ---

export async function loadMonthTrades(y: number, m: number): Promise<Record<string, Trade[]>> {
  try {
    const r = await dbOp<Record<string, Trade[]> | null>(STORE_TRADES, 'readonly', (st, res, rej) => {
      const q = st.get(mk(y, m));
      q.onsuccess = (e) => res((e.target as IDBRequest).result ?? null);
      q.onerror = rej;
    });
    if (!r || typeof r !== 'object' || Array.isArray(r)) return {};
    return r;
  } catch {
    return {};
  }
}

export async function saveMonthTrades(
  y: number,
  m: number,
  data: Record<string, Trade[]>
): Promise<void> {
  try {
    const ex = await loadMonthTrades(y, m);
    const hasNew = Object.values(data).some((a) => a && a.length > 0);
    const hasOld = ex && Object.values(ex).some((a) => a && a.length > 0);
    if (!hasNew && hasOld) return;
    await dbOp<void>(STORE_TRADES, 'readwrite', (st, res, rej) => {
      const q = st.put(data, mk(y, m));
      q.onsuccess = () => res();
      q.onerror = rej;
    });
  } catch {
    throw new Error('Failed to save trades');
  }
}

export async function loadAllTrades(): Promise<Trade[]> {
  try {
    const keys = await dbOp<IDBValidKey[]>(STORE_TRADES, 'readonly', (st, res, rej) => {
      const q = st.getAllKeys();
      q.onsuccess = (e) => res((e.target as IDBRequest).result as IDBValidKey[]);
      q.onerror = rej;
    });

    const all: Trade[] = [];
    const promises = keys.map((k) =>
      dbOp<Record<string, Trade[]>>(STORE_TRADES, 'readonly', (st, res, rej) => {
        const q = st.get(k);
        q.onsuccess = (e) => res((e.target as IDBRequest).result ?? {});
        q.onerror = rej;
      })
    );

    const results = await Promise.all(promises);
    results.forEach((data) => {
      if (data && typeof data === 'object') {
        Object.values(data).forEach((ts) => (ts || []).forEach((t) => all.push(t)));
      }
    });

    all.sort((a, b) => (a.savedAt || 0) - (b.savedAt || 0));
    return all;
  } catch {
    return [];
  }
}

// --- Note Operations ---

export async function loadNote(y: number, m: number, d: number): Promise<NoteData> {
  try {
    const r = await dbOp<NoteData | null>(STORE_NOTES, 'readonly', (st, res, rej) => {
      const q = st.get(nk(y, m, d));
      q.onsuccess = (e) => res((e.target as IDBRequest).result ?? null);
      q.onerror = rej;
    });
    return r || { text: '', images: [] };
  } catch {
    return { text: '', images: [] };
  }
}

export async function saveNote(y: number, m: number, d: number, data: NoteData): Promise<void> {
  try {
    await dbOp<void>(STORE_NOTES, 'readwrite', (st, res, rej) => {
      const q = st.put(data, nk(y, m, d));
      q.onsuccess = () => res();
      q.onerror = rej;
    });
  } catch {
    throw new Error('Failed to save note');
  }
}

export async function loadMonthNotes(
  y: number,
  m: number
): Promise<Record<string, NoteData>> {
  const days = new Date(y, m + 1, 0).getDate();
  const noteBatch: Record<string, NoteData> = {};
  const promises: Promise<void>[] = [];

  for (let d = 1; d <= days; d++) {
    promises.push(
      loadNote(y, m, d).then((note) => {
        if (note.text || note.images.length) {
          noteBatch[String(d)] = note;
        }
      })
    );
  }

  await Promise.all(promises);
  return noteBatch;
}

// --- Import / Export ---

export async function exportAllData(): Promise<object> {
  const [tk, nk2] = await Promise.all([
    dbOp<IDBValidKey[]>(STORE_TRADES, 'readonly', (st, res, rej) => {
      const q = st.getAllKeys();
      q.onsuccess = (e) => res((e.target as IDBRequest).result as IDBValidKey[]);
      q.onerror = rej;
    }),
    dbOp<IDBValidKey[]>(STORE_NOTES, 'readonly', (st, res, rej) => {
      const q = st.getAllKeys();
      q.onsuccess = (e) => res((e.target as IDBRequest).result as IDBValidKey[]);
      q.onerror = rej;
    }),
  ]);

  const dump: Record<string, Record<string, unknown>> = { trades: {}, notes: {} };

  const tradePromises = tk.map(async (k) => {
    dump.trades[String(k)] = await dbOp(STORE_TRADES, 'readonly', (st, res, rej) => {
      const q = st.get(k);
      q.onsuccess = (e) => res((e.target as IDBRequest).result);
      q.onerror = rej;
    });
  });

  const notePromises = nk2.map(async (k) => {
    dump.notes[String(k)] = await dbOp(STORE_NOTES, 'readonly', (st, res, rej) => {
      const q = st.get(k);
      q.onsuccess = (e) => res((e.target as IDBRequest).result);
      q.onerror = rej;
    });
  });

  await Promise.all([...tradePromises, ...notePromises]);
  return dump;
}

export async function importAllData(
  dump: { trades?: Record<string, unknown>; notes?: Record<string, unknown> }
): Promise<void> {
  const trades = dump.trades || dump;
  const notes = dump.notes || {};

  const tradeEntries = Object.entries(trades);
  const noteEntries = Object.entries(notes);

  // Process in batches to avoid blocking
  const BATCH_SIZE = 50;
  for (let i = 0; i < tradeEntries.length; i += BATCH_SIZE) {
    const batch = tradeEntries.slice(i, i + BATCH_SIZE);
    await Promise.all(
      batch.map(([k, v]) =>
        dbOp<void>(STORE_TRADES, 'readwrite', (st, res, rej) => {
          const q = st.put(v, k);
          q.onsuccess = () => res();
          q.onerror = rej;
        })
      )
    );
  }

  for (let i = 0; i < noteEntries.length; i += BATCH_SIZE) {
    const batch = noteEntries.slice(i, i + BATCH_SIZE);
    await Promise.all(
      batch.map(([k, v]) =>
        dbOp<void>(STORE_NOTES, 'readwrite', (st, res, rej) => {
          const q = st.put(v, k);
          q.onsuccess = () => res();
          q.onerror = rej;
        })
      )
    );
  }
}

export async function deleteAllData(): Promise<void> {
  const [tk, nk2] = await Promise.all([
    dbOp<IDBValidKey[]>(STORE_TRADES, 'readonly', (st, res, rej) => {
      const q = st.getAllKeys();
      q.onsuccess = (e) => res((e.target as IDBRequest).result as IDBValidKey[]);
      q.onerror = rej;
    }),
    dbOp<IDBValidKey[]>(STORE_NOTES, 'readonly', (st, res, rej) => {
      const q = st.getAllKeys();
      q.onsuccess = (e) => res((e.target as IDBRequest).result as IDBValidKey[]);
      q.onerror = rej;
    }),
  ]);

  await Promise.all([
    ...tk.map((k) =>
      dbOp<void>(STORE_TRADES, 'readwrite', (st, res, rej) => {
        const q = st.delete(k);
        q.onsuccess = () => res();
        q.onerror = rej;
      })
    ),
    ...nk2.map((k) =>
      dbOp<void>(STORE_NOTES, 'readwrite', (st, res, rej) => {
        const q = st.delete(k);
        q.onsuccess = () => res();
        q.onerror = rej;
      })
    ),
  ]);
}
