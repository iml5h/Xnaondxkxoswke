// ============================================================
// T-Journal Pro — Core Utilities & Statistics Engine
// ============================================================

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Trade, StatsResult, NoteData } from '@/types';

// shadcn compatibility
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- ID Generation (collision-resistant) ---
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

/**
 * Generates a collision-resistant numeric ID for trades.
 * Combines timestamp (ms) with a 3-digit random suffix so two trades
 * saved within the same millisecond don't end up with the same id.
 */
export function generateTradeId(): number {
  const rand = Math.floor(Math.random() * 900) + 100; // 100-999
  return Date.now() * 1000 + rand;
}

// --- Smart Number Formatting ---
/**
 * Formats profit numbers with intelligent compaction:
 * 1,000+ → "1k", 10,000+ → "10k", 100,000+ → "100k", 1,000,000+ → "1M"
 * Used in calendar cells to prevent layout overflow.
 */
export function fmtSmart(n: number): string {
  const absVal = Math.abs(n);
  const sign = n >= 0 ? '+' : '-';
  if (absVal >= 1_000_000) {
    return `${sign}${(absVal / 1_000_000).toFixed(absVal % 1_000_000 === 0 ? 0 : 1)}M`;
  }
  if (absVal >= 100_000) {
    return `${sign}${(absVal / 1_000).toFixed(0)}k`;
  }
  if (absVal >= 10_000) {
    return `${sign}${(absVal / 1_000).toFixed(0)}k`;
  }
  if (absVal >= 1_000) {
    return `${sign}${(absVal / 1_000).toFixed(1)}k`;
  }
  return `${sign}$${absVal.toFixed(2)}`;
}

/** Full format for tooltips and detailed views */
export function fmtFull(n: number): string {
  const a = Math.abs(n).toFixed(2);
  return n >= 0 ? `+$${a}` : `-$${a}`;
}

/** Primary format function (alias for fmtFull) */
export function fmt(n: number): string {
  return fmtFull(n);
}

export function fmtSimple(n: number): string {
  return n >= 0 ? `$${n.toFixed(2)}` : `-$${Math.abs(n).toFixed(2)}`;
}

// --- Statistics Engine ---
export function calcStats(arr: Trade[]): StatsResult {
  let wins = 0;
  let losses = 0;
  let gP = 0;
  let gL = 0;
  let rrs = 0;
  let rrc = 0;
  let lots = 0;

  arr.forEach((t) => {
    const p = parseFloat(t.pnl) || 0;
    lots += parseFloat(t.lot || '0');
    if (p > 0) {
      wins++;
      gP += p;
    } else if (p < 0) {
      losses++;
      gL += Math.abs(p);
    }
    if (p > 0 && t.rrr) {
      const r = parseFloat(String(t.rrr).replace(/.*:/, ''));
      if (!isNaN(r) && r > 0) {
        rrs += r;
        rrc++;
      }
    }
  });

  const n = wins + losses;
  const wr = n > 0 ? Math.round((wins / n) * 100) : null;
  const pf = gL > 0 ? (gP / gL).toFixed(2) : gP > 0 ? '\u221e' : null;
  const avgW = wins > 0 ? gP / wins : null;
  const avgL = losses > 0 ? gL / losses : null;
  const exp =
    avgW !== null && avgL !== null && n > 0
      ? (wins / n) * avgW - (losses / n) * avgL
      : null;
  const best = arr.length ? Math.max(...arr.map((t) => parseFloat(t.pnl) || 0)) : null;

  // Streak calculation
  const sorted = [...arr].sort((a, b) => (a.savedAt || 0) - (b.savedAt || 0));
  let streak = 0;
  let streakType: 'W' | 'L' | null = null;

  if (sorted.length) {
    const lp = parseFloat(sorted[sorted.length - 1].pnl) || 0;
    streakType = lp > 0 ? 'W' : lp < 0 ? 'L' : null;
    if (streakType) {
      for (let i = sorted.length - 1; i >= 0; i--) {
        const p = parseFloat(sorted[i].pnl) || 0;
        if ((streakType === 'W' && p > 0) || (streakType === 'L' && p < 0)) streak++;
        else break;
      }
    }
  }

  return {
    total: arr.length,
    wins,
    losses,
    wr,
    pf,
    pnl: arr.reduce((s, t) => s + (parseFloat(t.pnl) || 0), 0),
    avgW,
    avgL,
    exp,
    avgRRR: rrc > 0 ? (rrs / rrc).toFixed(2) : null,
    gP,
    gL,
    lots: lots.toFixed(2),
    best,
    streak,
    streakType,
  };
}

export function dayStats(day: string, trades: Record<string, Trade[]>): { count: number; pnl: number } {
  const ts = trades[day] || [];
  return {
    count: ts.length,
    pnl: ts.reduce((s, t) => s + (parseFloat(t.pnl) || 0), 0),
  };
}

export function hasNote(day: string, notes: Record<string, NoteData>): boolean {
  const n = notes[day];
  return !!(n && (n.text || (n.images && n.images.length > 0)));
}

// --- Chart Helpers ---
export const chartTextStyle = {
  color: 'rgba(232,237,245,.28)',
  font: { size: 9, family: "'DM Mono', 'Fira Code', Consolas, monospace" },
};
export const chartGridColor = 'rgba(255,255,255,.04)';

// --- File to Base64 ---
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// --- Haptic Feedback ---
export function hapticLight(): void {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(8);
    } catch {
      // ignore
    }
  }
}

export function hapticMedium(): void {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(15);
    } catch {
      // ignore
    }
  }
}

// --- Date Helpers ---
export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning \u2600\uFE0F';
  if (hour < 17) return 'Good afternoon \u26A1';
  return 'Good evening \uD83C\uDF19';
}

export function formatDateLong(d: Date): string {
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatDateShort(d: Date): string {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// --- Trade badge helpers ---
export function getResultBadge(pnl: number, result?: string): { cls: string; label: string } {
  if (result === 'be') return { cls: 'bbe', label: 'B/E' };
  if (pnl > 0) return { cls: 'bwin', label: 'WIN' };
  if (pnl < 0) return { cls: 'blos', label: 'LOSS' };
  return { cls: 'bbe', label: 'B/E' };
}

export function getPnlColor(pnl: number): string {
  if (pnl > 0) return 'var(--green)';
  if (pnl < 0) return 'var(--red)';
  return 'var(--t3)';
}

export function getWinRateColor(wr: number | null): string {
  if (wr === null) return 'var(--t3)';
  return wr >= 50 ? 'var(--green)' : 'var(--red)';
}

export function getProfitFactorColor(pf: string | null): string {
  const v = parseFloat(pf || '0');
  if (v >= 1.5) return 'var(--green)';
  if (v >= 1) return 'var(--yellow)';
  return 'var(--red)';
}
